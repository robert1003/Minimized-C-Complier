int main() {
    int a, b;
    float c, d;
    write("input:");
    a = read();
    write("input:");
    b = read();
    write("input:");
    c = fread();
    write("input:");
    d = fread();

    write(a);
    write("\n");
    write(b);
    write("\n");
    write(c);
    write("\n");
    write(d);
    write("\n");
    return 0;
}
